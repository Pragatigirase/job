from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import transaction

from .forms import CustomUserCreationForm, CandidateProfileForm, EmployerProfileForm
from .models import User, CandidateProfile, EmployerProfile

def register(request):
    if request.user.is_authenticated:
        return redirect('home')
        
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                user = form.save()
                user.user_type = form.cleaned_data.get('user_type')
                user.save()
                
                # Create corresponding profile
                if user.user_type == 'candidate':
                    CandidateProfile.objects.create(user=user)
                elif user.user_type == 'employer':
                    EmployerProfile.objects.create(user=user)
                    
                login(request, user)
                messages.success(request, f"Account created successfully! Welcome, {user.username}!")
                return redirect(user.get_dashboard_url())
    else:
        form = CustomUserCreationForm()
    
    return render(request, 'accounts/register.html', {'form': form})

@login_required
def profile(request):
    user = request.user
    
    if user.user_type == 'candidate':
        profile = getattr(user, 'candidate_profile', None)
        if not profile:
            profile = CandidateProfile.objects.create(user=user)
        
        context = {
            'user': user,
            'profile': profile,
        }
        return render(request, 'accounts/profile.html', context)
    
    elif user.user_type == 'employer':
        profile = getattr(user, 'employer_profile', None)
        if not profile:
            profile = EmployerProfile.objects.create(user=user)
        
        context = {
            'user': user,
            'profile': profile,
        }
        return render(request, 'accounts/profile.html', context)
    
    return redirect('home')

@login_required
def edit_profile(request):
    user = request.user
    
    if user.user_type == 'candidate':
        profile = getattr(user, 'candidate_profile', None)
        if not profile:
            profile = CandidateProfile.objects.create(user=user)
            
        if request.method == 'POST':
            form = CandidateProfileForm(request.POST, request.FILES, instance=profile)
            if form.is_valid():
                form.save()
                messages.success(request, 'Your profile has been updated successfully!')
                return redirect('profile')
        else:
            form = CandidateProfileForm(instance=profile)
            
        context = {
            'form': form,
            'user_type': 'candidate'
        }
        return render(request, 'accounts/edit_profile.html', context)
    
    elif user.user_type == 'employer':
        profile = getattr(user, 'employer_profile', None)
        if not profile:
            profile = EmployerProfile.objects.create(user=user)
            
        if request.method == 'POST':
            form = EmployerProfileForm(request.POST, request.FILES, instance=profile)
            if form.is_valid():
                form.save()
                messages.success(request, 'Your company profile has been updated successfully!')
                return redirect('profile')
        else:
            form = EmployerProfileForm(instance=profile)
            
        context = {
            'form': form,
            'user_type': 'employer'
        }
        return render(request, 'accounts/edit_profile.html', context)
    
    return redirect('home')

def logout_view(request):
    logout(request)
    messages.success(request, "You have been successfully logged out.")
    return redirect('home')