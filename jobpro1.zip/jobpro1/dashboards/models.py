from django.db import models

# No models needed for this app as they are defined in other apps
# This file is kept for Django's convention
