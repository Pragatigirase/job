from django.urls import path
from . import views

urlpatterns = [
    # Dashboard main views
    path('candidate/', views.candidate_dashboard, name='candidate_dashboard'),
    path('employer/', views.employer_dashboard, name='employer_dashboard'),
    path('admin/', views.admin_dashboard, name='admin_dashboard'),
    
    # Candidate specific views
    path('candidate/applied-jobs/', views.applied_jobs, name='applied_jobs'),
    path('candidate/saved-jobs/', views.saved_jobs, name='saved_jobs'),
    
    # Employer specific views
    path('employer/jobs/', views.posted_jobs, name='posted_jobs'),
    path('employer/jobs/add/', views.add_job, name='add_job'),
    path('employer/jobs/<int:pk>/edit/', views.edit_job, name='edit_job'),
    path('employer/jobs/<int:pk>/delete/', views.delete_job, name='delete_job'),
    path('employer/jobs/<int:pk>/publish/', views.publish_job, name='publish_job'),
    path('employer/jobs/<int:pk>/close/', views.close_job, name='close_job'),
    path('employer/jobs/<int:pk>/applicants/', views.job_applicants, name='job_applicants'),
    path('employer/applicants/<int:pk>/update-status/', views.update_application_status, name='update_application_status'),
    
    # Admin specific views
    path('admin/jobs/', views.admin_jobs, name='admin_jobs'),
    path('admin/jobs/<int:pk>/approve/', views.approve_job, name='approve_job'),
    path('admin/jobs/<int:pk>/reject/', views.reject_job, name='reject_job'),
    path('admin/users/', views.admin_users, name='admin_users'),
    path('admin/users/<int:pk>/toggle-status/', views.toggle_user_status, name='toggle_user_status'),
]
