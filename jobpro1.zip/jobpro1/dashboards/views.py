from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.http import HttpResponseForbidden

from accounts.models import User, CandidateProfile, EmployerProfile
from jobs.models import Job, JobApplication, SavedJob, JobCategory
from jobs.forms import JobForm
from .forms import ApplicationStatusForm

@login_required
def candidate_dashboard(request):
    # Ensure user is a candidate
    if request.user.user_type != 'candidate':
        messages.error(request, "Access denied. You are not a candidate.")
        return redirect('home')
    
    candidate = getattr(request.user, 'candidate_profile', None)
    if not candidate:
        # Create a profile if one doesn't exist
        candidate = CandidateProfile.objects.create(user=request.user)
    
    # Dashboard statistics
    applied_jobs_count = JobApplication.objects.filter(candidate=candidate).count()
    saved_jobs_count = SavedJob.objects.filter(user=request.user).count()
    
    # Recent job applications
    recent_applications = JobApplication.objects.filter(candidate=candidate).order_by('-created_at')[:5]
    
    # Recommended jobs (based on recent applications categories)
    applied_categories = JobApplication.objects.filter(
        candidate=candidate
    ).values_list('job__category', flat=True).distinct()
    
    recommended_jobs = Job.objects.filter(
        status='open', 
        category__in=applied_categories
    ).exclude(
        applications__candidate=candidate
    ).order_by('-created_at')[:5]
    
    context = {
        'candidate': candidate,
        'applied_jobs_count': applied_jobs_count,
        'saved_jobs_count': saved_jobs_count,
        'recent_applications': recent_applications,
        'recommended_jobs': recommended_jobs,
    }
    
    return render(request, 'dashboards/candidate_dashboard.html', context)

@login_required
def employer_dashboard(request):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        # Create a profile if one doesn't exist
        employer = EmployerProfile.objects.create(user=request.user)
    
    # Dashboard statistics
    total_jobs = Job.objects.filter(company=employer).count()
    active_jobs = Job.objects.filter(company=employer, status='open').count()
    total_applications = JobApplication.objects.filter(job__company=employer).count()
    
    # Recent job posts
    recent_jobs = Job.objects.filter(company=employer).order_by('-created_at')[:5]
    
    # Recent applications
    recent_applications = JobApplication.objects.filter(
        job__company=employer
    ).order_by('-created_at')[:5]
    
    context = {
        'employer': employer,
        'total_jobs': total_jobs,
        'active_jobs': active_jobs,
        'total_applications': total_applications,
        'recent_jobs': recent_jobs,
        'recent_applications': recent_applications,
    }
    
    return render(request, 'dashboards/employer_dashboard.html', context)

@login_required
def admin_dashboard(request):
    # Ensure user is an admin
    if not request.user.is_staff:
        messages.error(request, "Access denied. Admin privileges required.")
        return redirect('home')
    
    # Dashboard statistics
    total_users = User.objects.count()
    total_candidates = User.objects.filter(user_type='candidate').count()
    total_employers = User.objects.filter(user_type='employer').count()
    total_jobs = Job.objects.count()
    active_jobs = Job.objects.filter(status='open').count()
    total_applications = JobApplication.objects.count()
    
    # Recent users
    recent_users = User.objects.order_by('-date_joined')[:5]
    
    # Recent job posts
    recent_jobs = Job.objects.order_by('-created_at')[:5]
    
    context = {
        'total_users': total_users,
        'total_candidates': total_candidates,
        'total_employers': total_employers,
        'total_jobs': total_jobs,
        'active_jobs': active_jobs,
        'total_applications': total_applications,
        'recent_users': recent_users,
        'recent_jobs': recent_jobs,
    }
    
    return render(request, 'dashboards/admin_dashboard.html', context)

@login_required
def applied_jobs(request):
    # Ensure user is a candidate
    if request.user.user_type != 'candidate':
        messages.error(request, "Access denied. You are not a candidate.")
        return redirect('home')
    
    candidate = getattr(request.user, 'candidate_profile', None)
    if not candidate:
        return redirect('edit_profile')
    
    applications = JobApplication.objects.filter(candidate=candidate).order_by('-created_at')
    
    paginator = Paginator(applications, 10)  # Show 10 applications per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
    }
    
    return render(request, 'dashboards/applied_jobs.html', context)

@login_required
def saved_jobs(request):
    # Ensure user is signed in
    saved = SavedJob.objects.filter(user=request.user).order_by('-created_at')
    
    paginator = Paginator(saved, 10)  # Show 10 saved jobs per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
    }
    
    return render(request, 'dashboards/saved_jobs.html', context)

@login_required
def posted_jobs(request):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        return redirect('edit_profile')
    
    status_filter = request.GET.get('status', '')
    if status_filter and status_filter in dict(Job.STATUS_CHOICES):
        jobs = Job.objects.filter(company=employer, status=status_filter).order_by('-created_at')
    else:
        jobs = Job.objects.filter(company=employer).order_by('-created_at')
    
    # Add application count to each job
    jobs = jobs.annotate(application_count=Count('applications'))
    
    paginator = Paginator(jobs, 10)  # Show 10 jobs per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'status_filter': status_filter,
    }
    
    return render(request, 'dashboards/posted_jobs.html', context)

@login_required
def add_job(request):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        return redirect('edit_profile')
    
    if request.method == 'POST':
        form = JobForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.company = employer
            job.save()
            messages.success(request, "Job posting created successfully!")
            return redirect('posted_jobs')
    else:
        form = JobForm()
    
    context = {
        'form': form,
        'action': 'Add',
    }
    
    return render(request, 'jobs/job_form.html', context)

@login_required
def edit_job(request, pk):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        return redirect('edit_profile')
    
    job = get_object_or_404(Job, pk=pk, company=employer)
    
    if request.method == 'POST':
        form = JobForm(request.POST, instance=job)
        if form.is_valid():
            form.save()
            messages.success(request, "Job posting updated successfully!")
            return redirect('posted_jobs')
    else:
        form = JobForm(instance=job)
    
    context = {
        'form': form,
        'job': job,
        'action': 'Edit',
    }
    
    return render(request, 'jobs/job_form.html', context)

@login_required
def delete_job(request, pk):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        return redirect('edit_profile')
    
    job = get_object_or_404(Job, pk=pk, company=employer)
    
    if request.method == 'POST':
        job.delete()
        messages.success(request, "Job posting deleted successfully!")
        return redirect('posted_jobs')
    
    context = {
        'job': job,
    }
    
    return render(request, 'dashboards/job_confirm_delete.html', context)

@login_required
def publish_job(request, pk):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        return redirect('edit_profile')
    
    job = get_object_or_404(Job, pk=pk, company=employer)
    
    if job.status == 'draft':
        job.status = 'open'
        job.save()
        messages.success(request, "Job posting published successfully!")
    
    return redirect('posted_jobs')

@login_required
def close_job(request, pk):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        return redirect('edit_profile')
    
    job = get_object_or_404(Job, pk=pk, company=employer)
    
    if job.status == 'open':
        job.status = 'closed'
        job.save()
        messages.success(request, "Job posting closed successfully!")
    
    return redirect('posted_jobs')

@login_required
def job_applicants(request, pk):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        return redirect('edit_profile')
    
    job = get_object_or_404(Job, pk=pk, company=employer)
    
    # Filter applications
    status_filter = request.GET.get('status', '')
    if status_filter and status_filter in dict(JobApplication.STATUS_CHOICES):
        applications = job.applications.filter(status=status_filter).order_by('-created_at')
    else:
        applications = job.applications.all().order_by('-created_at')
    
    paginator = Paginator(applications, 10)  # Show 10 applications per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'job': job,
        'page_obj': page_obj,
        'status_filter': status_filter,
    }
    
    return render(request, 'dashboards/job_applicants.html', context)

@login_required
def update_application_status(request, pk):
    # Ensure user is an employer
    if request.user.user_type != 'employer':
        messages.error(request, "Access denied. You are not an employer.")
        return redirect('home')
    
    employer = getattr(request.user, 'employer_profile', None)
    if not employer:
        return redirect('edit_profile')
    
    application = get_object_or_404(JobApplication, pk=pk, job__company=employer)
    
    if request.method == 'POST':
        form = ApplicationStatusForm(request.POST, instance=application)
        if form.is_valid():
            form.save()
            messages.success(request, f"Application status updated to {application.get_status_display()}!")
            return redirect('job_applicants', pk=application.job.pk)
    else:
        form = ApplicationStatusForm(instance=application)
    
    context = {
        'form': form,
        'application': application,
    }
    
    return render(request, 'dashboards/update_application_status.html', context)

@login_required
def admin_jobs(request):
    # Ensure user is an admin
    if not request.user.is_staff:
        messages.error(request, "Access denied. Admin privileges required.")
        return redirect('home')
    
    # Filter jobs
    status_filter = request.GET.get('status', '')
    if status_filter and status_filter in dict(Job.STATUS_CHOICES):
        jobs = Job.objects.filter(status=status_filter).order_by('-created_at')
    else:
        jobs = Job.objects.all().order_by('-created_at')
    
    paginator = Paginator(jobs, 20)  # Show 20 jobs per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'status_filter': status_filter,
    }
    
    return render(request, 'dashboards/admin_jobs.html', context)

@login_required
def approve_job(request, pk):
    # Ensure user is an admin
    if not request.user.is_staff:
        messages.error(request, "Access denied. Admin privileges required.")
        return redirect('home')
    
    job = get_object_or_404(Job, pk=pk)
    
    if job.status == 'draft':
        job.status = 'open'
        job.save()
        messages.success(request, "Job posting approved and published!")
    
    return redirect('admin_jobs')

@login_required
def reject_job(request, pk):
    # Ensure user is an admin
    if not request.user.is_staff:
        messages.error(request, "Access denied. Admin privileges required.")
        return redirect('home')
    
    job = get_object_or_404(Job, pk=pk)
    
    if job.status != 'closed':
        job.status = 'closed'
        job.save()
        messages.success(request, "Job posting rejected/closed!")
    
    return redirect('admin_jobs')

@login_required
def admin_users(request):
    # Ensure user is an admin
    if not request.user.is_staff:
        messages.error(request, "Access denied. Admin privileges required.")
        return redirect('home')
    
    # Filter users
    user_type_filter = request.GET.get('user_type', '')
    if user_type_filter and user_type_filter in dict(User.USER_TYPE_CHOICES):
        users = User.objects.filter(user_type=user_type_filter).order_by('-date_joined')
    else:
        users = User.objects.all().order_by('-date_joined')
    
    paginator = Paginator(users, 20)  # Show 20 users per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'user_type_filter': user_type_filter,
    }
    
    return render(request, 'dashboards/admin_users.html', context)

@login_required
def toggle_user_status(request, pk):
    # Ensure user is an admin
    if not request.user.is_staff:
        messages.error(request, "Access denied. Admin privileges required.")
        return redirect('home')
    
    user = get_object_or_404(User, pk=pk)
    
    # Don't allow toggling own account
    if user == request.user:
        messages.error(request, "You cannot change your own account status.")
        return redirect('admin_users')
    
    user.is_active = not user.is_active
    user.save()
    
    status = "activated" if user.is_active else "deactivated"
    messages.success(request, f"User {user.username} has been {status}!")
    
    return redirect('admin_users')
